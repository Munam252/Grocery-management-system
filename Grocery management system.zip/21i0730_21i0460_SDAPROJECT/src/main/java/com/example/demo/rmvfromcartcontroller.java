package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class rmvfromcartcontroller {
    @FXML
    private TextField CartID;
    private int id;
    @FXML
    private TextField productID;
    private int prod_id;
    @FXML
    private Button remove;

    public void remove() throws IOException {
        id=Integer.parseInt(CartID.getText());
        prod_id=Integer.parseInt(productID.getText());
        Customer obj =new Customer();
        obj.rmvfromcart(id,prod_id);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("menu.fxml"));
        Parent root = fxmlLoader.load();

        Stage stage = (Stage) remove.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
