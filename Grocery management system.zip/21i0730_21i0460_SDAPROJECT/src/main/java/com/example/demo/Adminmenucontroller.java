package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Adminmenucontroller {
    @FXML private Button REG;
    @FXML private Button storeanduser;
    @FXML private Button productcatalog;
    @FXML private Button logout;

    public void REG() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("managerreg.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) REG.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void storeanduser() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("managestore.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) storeanduser.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void productcatalog() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("productcatalog.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) productcatalog.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void logout() throws IOException {
        System.out.println("Admin Successfully logged out.");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GMS.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) logout.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
