package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class paymentbycashcontroller {
    @FXML
    private TextField Amount;
    private int amount;
    @FXML
    private TextField TotalBill;
    private int bill;
    @FXML
    private TextField customerid;
    private int id;
    @FXML
    private Button Payment;
    public void Payment() throws IOException {
        amount=Integer.parseInt(Amount.getText());
        bill=Integer.parseInt(TotalBill.getText());
        id=Integer.parseInt(customerid.getText());
        Customer obj =new Customer();
        obj.makepaymentbycash(amount,bill,id);

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("menu.fxml"));
        Parent root = fxmlLoader.load();

        Stage stage = (Stage) Payment.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
