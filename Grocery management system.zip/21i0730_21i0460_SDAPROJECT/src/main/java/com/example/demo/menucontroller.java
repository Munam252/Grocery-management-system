package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class menucontroller {
    @FXML
    private Button CART;
    @FXML
    private Button FEEDBACK;
    @FXML
    private Button PAYMENT;
    @FXML
    private Button LOGOUT;

    public void CART() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Cart.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) CART.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void FEEDBACK() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("customerfeedback.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) FEEDBACK.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void PAYMENT() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("payment.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) PAYMENT.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void LOGOUT() throws IOException
    {
        System.out.println("Customer Successfully logged out.");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GMS.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) LOGOUT.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
