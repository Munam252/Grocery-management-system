package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;

public class Feedback {
    private int customerId; // Assuming customer_id is an integer
    private String feedbackText;

   public Feedback()
   {}
    public Feedback(int customerId, String feedbackText) {
        this.customerId = customerId;
        this.feedbackText = feedbackText;
    }

    public void saveFeedback(int customerId, String feedbackText) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to insert feedback into the feedback table
            String sql = "INSERT INTO feedback (customer_id, feedback_text) VALUES (?, ?)";

            // Creating a PreparedStatement object to execute the query
            preparedStatement = connection.prepareStatement(sql);

            // Setting values for the parameters in the SQL query
            preparedStatement.setInt(1, customerId);
            preparedStatement.setString(2, feedbackText);

            // Executing the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Checking the result
            if (rowsAffected > 0) {
                System.out.println("Feedback saved successfully!");
            } else {
                System.out.println("Failed to save feedback.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void displayAllFeedback() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to select all feedback information
            String sql = "SELECT feedback_id, customer_id, feedback_text,feedback_reply FROM feedback";

            // Creating a PreparedStatement object to execute the query
            preparedStatement = connection.prepareStatement(sql);

            // Executing the query and obtaining the result set
            resultSet = preparedStatement.executeQuery();

            // Displaying feedback information
            while (resultSet.next()) {

                int feedbackId = resultSet.getInt("feedback_id");
                int customerId = resultSet.getInt("customer_id");
                String feedbackText = resultSet.getString("feedback_text");
                String feedbackReply = resultSet.getString("feedback_reply");


                System.out.println("Feedback ID: " + feedbackId);
                System.out.println("Customer ID: " + customerId);
                System.out.println("Feedback Text: " + feedbackText);
                System.out.println("Feedback reply: " + feedbackReply);
                System.out.println("----------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void FeedbackReply(int feedbackId, String feedbackReply) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to update feedback_reply for the given feedback_id
            String sql = "UPDATE feedback SET feedback_reply = ? WHERE feedback_id = ?";

            // Creating a PreparedStatement object to execute the query
            preparedStatement = connection.prepareStatement(sql);

            // Setting values for the parameters in the SQL query
            preparedStatement.setString(1, feedbackReply);
            preparedStatement.setInt(2, feedbackId);

            // Executing the update query
            int rowsAffected = preparedStatement.executeUpdate();

            // Checking the result
            if (rowsAffected > 0) {
                System.out.println("Feedback reply updated successfully!");
            } else {
                System.out.println("Failed to update feedback reply.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
