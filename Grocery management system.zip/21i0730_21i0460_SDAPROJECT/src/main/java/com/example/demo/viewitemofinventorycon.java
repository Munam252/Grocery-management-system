package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class viewitemofinventorycon {
    @FXML
    private TextField storeid;
    private int id;
    @FXML
    private TextField prodid;
    private int p_id;
    @FXML
    private Button viewitem;

    public void viewinventoryitem() throws IOException {
        id=Integer.parseInt(storeid.getText());
        p_id=Integer.parseInt(prodid.getText());
        Manager obj=new Manager();
        obj.viewItemofInventory(id,p_id);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Managermenu.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) viewitem.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
