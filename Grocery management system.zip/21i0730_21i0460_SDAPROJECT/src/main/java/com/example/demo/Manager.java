package com.example.demo;
import java.sql.*;

public class Manager implements user {
    private String name;
    private String password;
    private String cnic;
    private String email;
    private String address;
    private String storeLocation;
    private Feedback feedbacks;
    public Manager(String name, String email, String address, String cnic, String password, String storeLocation) {
        this.name = name;
        this.password = password;
        this.cnic = cnic;
        this.email = email;
        this.address = address;
        this.storeLocation = storeLocation;
    }

    public Manager()
    {}

    public void viewPayments()
    {
        Payment obj = new Payment();
        obj.viewAllPayments();
    }
    public void addItemtoinventory(int storeId, int productId, int quantity)
    {
        Store obj=new Store();
        obj.addItemtoinventory(storeId,productId,quantity);
    }
    public void removeItemfrominventory(int storeId, int productId){
        Store obj=new Store();
        obj.removeItemfrominventory(storeId,productId);
    }
    public void viewInventory(int storeId){
        Store obj=new Store();
        obj.viewInventory(storeId);
    }
    public void updateInventoryItem(int storeId, int productId, int quantity) {
        Store obj=new Store();
        obj.updateInventoryItem(storeId,productId,quantity);
    }
    public void viewItemofInventory(int storeId, int productId) {
        Store obj=new Store();
        obj.viewItemofInventory(storeId,productId);
    }
    public void viewFeedback()
    {
        feedbacks=new Feedback();
        feedbacks.displayAllFeedback();
    }
    public void replyfeedback(int id,String reply)
    {
        feedbacks=new Feedback();
        feedbacks.FeedbackReply(id,reply);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getcnic() {
        return cnic;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public String getAddress() {
        return address;
    }


    public boolean login(String inputUsername, String inputPassword) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to check if the provided username and password exist
            String selectSql = "SELECT * FROM Manager WHERE name = ? AND password = ?";

            // Creating a PreparedStatement object to execute the SELECT query
            preparedStatement = connection.prepareStatement(selectSql);

            // Setting values for the parameters in the SELECT query
            preparedStatement.setString(1, inputUsername);
            preparedStatement.setString(2, inputPassword);

            // Executing the SELECT query and getting the result set
            resultSet = preparedStatement.executeQuery();


            // Checking if any matching records were found
            if (resultSet.next()) {

                System.out.println("Login successful! Login status updated.");
                return true;
            } else {
                System.out.println("Invalid username or password. Login failed.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (resultSet != null) {
                    ((ResultSet) resultSet).close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
