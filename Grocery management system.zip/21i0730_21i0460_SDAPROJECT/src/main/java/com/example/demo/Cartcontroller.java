package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Cartcontroller {
    @FXML
    private Button addtocart;
    @FXML
    private Button rmvfromcart;
    @FXML
    private Button viewcart;

    public void addtocart() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("addtocart.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) addtocart.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void rmvfromcart() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("rmvfromcart.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) rmvfromcart.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void viewcart() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("viewcart.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) viewcart.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
