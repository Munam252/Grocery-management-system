package com.example.demo;
import java.sql.*;

public class CartProduct {
    private int cartId;
    private int productId;
    private int quantity;

    public CartProduct()
    {}

    public void addToCart(int cartId, int productId, int quantity) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        String sql = "INSERT INTO CartProduct (cart_id, product_id, quantity) VALUES (?, ?, ?)";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setInt(1, cartId);
            preparedStatement.setInt(2, productId);
            preparedStatement.setInt(3, quantity);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Item added to cart successfully!");
            } else {
                System.out.println("Failed to add item to cart.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeFromCart(int cartId, int productId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        String sql = "DELETE FROM CartProduct WHERE cart_id = ? AND product_id = ?";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setInt(1, cartId);
            preparedStatement.setInt(2, productId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Item removed from cart successfully!");
            } else {
                System.out.println("Failed to remove item from cart.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCart(int cartId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        String sql = "SELECT * FROM CartProduct WHERE cart_id = ?";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setInt(1, cartId);
            ResultSet resultSet = preparedStatement.executeQuery();

            System.out.println("Cart contents for Cart ID " + cartId + ":");
            while (resultSet.next()) {
                int productId = resultSet.getInt("product_id");
                int quantity = resultSet.getInt("quantity");

                System.out.println("Product ID: " + productId + ", Quantity: " + quantity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
