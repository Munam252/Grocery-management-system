package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Adminlogincontroller {
    @FXML
    private TextField username;
    private String USername;

    @FXML
    private TextField Password;

    private String pass;

    @FXML
    private Button login;

    public void setLogin() throws IOException {
        USername = username.getText();

        pass= Password.getText();

        Admin obj =new Admin();
        boolean result = obj.login(USername,pass);
        if(result)
        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
            Parent root = fxmlLoader.load();
            Stage stage = (Stage) login.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        else {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminlogin.fxml"));
            Parent root = fxmlLoader.load();
            Stage stage = (Stage) login.getScene().getWindow();
            stage.setScene(new Scene(root));
        }

    }
}
