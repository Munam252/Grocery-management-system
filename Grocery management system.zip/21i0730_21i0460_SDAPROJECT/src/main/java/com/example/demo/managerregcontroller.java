package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class managerregcontroller {

    @FXML
    private Button Register;

    @FXML
    private TextField username;
    private String name;

    @FXML
    private TextField Email;
    private String mail;
    @FXML
    private TextField Address;
    private String add;
    @FXML
    private TextField CNIC;
    private String cnic;
    @FXML
    private TextField Password;
    private String pass;

    @FXML
    private TextField storeloc;
    private String loc;

    public void Register() throws IOException {
        name = username.getText();
        mail= Email.getText();
        add = Address.getText();
        cnic = CNIC.getText();
        pass = Password.getText();
        loc=storeloc.getText();

        Admin obj=new Admin();
        obj.registration(name,mail,add,cnic,pass,loc);
        System.out.println("You have registered successfully a manager.");

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) Register.getScene().getWindow();
        stage.setScene(new Scene(root));

    }
}
