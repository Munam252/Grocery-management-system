package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class GMSCONTROLLER {
    @FXML
    private Button CUSTOMER;

    @FXML
    private Button Manager;

    @FXML
    private Button Admin;

    public void CUSTOMER() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Customerloginregister.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) CUSTOMER.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void MANAGER() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("managerlogin.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) Manager.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void ADMIN() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminlogin.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) Admin.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
