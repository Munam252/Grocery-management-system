package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class addtoproductcatalogcontroller {
    @FXML
    private TextField productid;
    private int id;
    @FXML
    private TextField category;
    private String cat;
    @FXML
    private TextField manufacturer;
    private String manu;

    @FXML
    private Button addtocatalog;

    public void addtocatalog() throws IOException {
        id=Integer.parseInt(productid.getText());
        cat=category.getText();
        manu=manufacturer.getText();
        Admin obj =new Admin();
        obj.addtoproductcatalog(id,cat,manu);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) addtocatalog.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
