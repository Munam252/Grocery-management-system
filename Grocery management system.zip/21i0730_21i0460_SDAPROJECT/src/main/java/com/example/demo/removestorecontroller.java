package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class removestorecontroller {
    @FXML private TextField storeid;
    private int id;
    @FXML private TextField storeloc;
    private String loc;
    @FXML private Button rmvstore;

    public void rmvstore() throws IOException {
        id=Integer.parseInt(storeid.getText());
        loc=storeloc.getText();
        Admin obj =new Admin();
        obj.removestore(id,loc);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) rmvstore.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
