package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BankAccount {

    private int accountID;
    private int customerID;
    private String cardNumber;
    private String accountType;

    public BankAccount()
    {}
    public boolean makePayment(String cardNumber, int billAmount) {
        int currentBalance = getBalanceFromDatabase(cardNumber);
        if (currentBalance >= billAmount) {
            currentBalance -= billAmount;

            String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
            String dbUser = "root";
            String dbPassword = "Alyan@072";

            try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
                String updateSql = "UPDATE BankAccount SET Balance = ? WHERE CardNumber = ?";
                try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
                    updateStatement.setInt(1, currentBalance);
                    updateStatement.setString(2, cardNumber);
                    updateStatement.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return true;
        } else {
            return false;
        }
    }

    private int getBalanceFromDatabase(String cardNumber) {
        int balance = 0;
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String selectSql = "SELECT Balance FROM BankAccount WHERE CardNumber = ?";
            try (PreparedStatement selectStatement = connection.prepareStatement(selectSql)) {
                selectStatement.setString(1, cardNumber);
                try (ResultSet resultSet = selectStatement.executeQuery()) {
                    if (resultSet.next()) {
                        balance = resultSet.getInt("Balance");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return balance;
    }
}

