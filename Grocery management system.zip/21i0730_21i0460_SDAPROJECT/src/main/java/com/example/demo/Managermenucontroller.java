package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Managermenucontroller {

    @FXML
    private Button logout;
    @FXML
    private Button inventory;
    @FXML
    private Button payment;
    @FXML
    private Button feedback;

    public void Logout() throws IOException {
        System.out.println("Manager Successfully logged out.");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GMS.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) logout.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void Inventory() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Inventory.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) inventory.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void Payment() throws IOException {
        Manager obj = new Manager();
        obj.viewPayments();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Managermenu.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) payment.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void Feedback() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("managefeedback.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) feedback.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
