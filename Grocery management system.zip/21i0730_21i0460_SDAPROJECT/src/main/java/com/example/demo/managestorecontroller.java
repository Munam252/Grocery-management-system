package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class managestorecontroller {
    @FXML private Button removestore;
    @FXML private Button viewstore;
    @FXML private Button storeadder;

    public void storeaddition() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("newPage.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) storeadder.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    public void removestore() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("removestore.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) removestore.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void viewstore() throws IOException {
        Admin obj =new Admin();
        obj.viewstore();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) viewstore.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
