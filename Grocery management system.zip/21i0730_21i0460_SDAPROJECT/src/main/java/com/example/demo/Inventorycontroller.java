package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Inventorycontroller {
    @FXML
    private Button Additem;
    @FXML
    private Button rmvitem;
    @FXML
    private Button viewInventory;
    @FXML
    private Button updateitem;
    @FXML
    private Button viewitem;

    public void Additem() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("additemtoinventory.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) Additem.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void rmvitem() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("rmvitemfrominventory.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) rmvitem.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void viewInventory() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("viewinventory.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) viewInventory.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void updateitem() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("updateitemininventory.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) updateitem.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void viewitem() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("viewitemofinventory.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) viewitem.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
