package com.example.demo;

import java.sql.*;

public class ProductCatalog {
    private int catalogId;
    private int productId;
    private String category;
    private String manufacturer;

    public ProductCatalog()
    {}
    public void addToProductCatalog(int productId, String category, String manufacturer) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "INSERT INTO ProductCatalog (product_id, category, manufacturer) VALUES (?, ?, ?)";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setInt(1, productId);
            preparedStatement.setString(2, category);
            preparedStatement.setString(3, manufacturer);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Product added to ProductCatalog successfully!");
            } else {
                System.out.println("Failed to add product to ProductCatalog.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeFromProductCatalog(int productId, String category, String manufacturer) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "DELETE FROM ProductCatalog WHERE product_id = ? AND category = ? AND manufacturer = ?";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setInt(1, productId);
            preparedStatement.setString(2, category);
            preparedStatement.setString(3, manufacturer);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Product removed from ProductCatalog successfully!");
            } else {
                System.out.println("Failed to remove product from ProductCatalog.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewProductCatalog() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "SELECT * FROM ProductCatalog";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql);
        ) {
            System.out.println("Product Catalog:");

            while (resultSet.next()) {
                int productId = resultSet.getInt("product_id");
                String category = resultSet.getString("category");
                String manufacturer = resultSet.getString("manufacturer");

                System.out.println("Product ID: " + productId + ", Category: " + category + ", Manufacturer: " + manufacturer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

