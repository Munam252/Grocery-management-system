package com.example.demo;

import java.sql.*;

public class Inventory {
    private int inventoryId;
    private int productId;
    private int storeId;
    private int quantity;
    Inventory(){}
    public void addItem(int storeId, int productId, int quantity) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "INSERT INTO Inventory (store_id, product_id, quantity) VALUES (?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, storeId);
            preparedStatement.setInt(2, productId);
            preparedStatement.setInt(3, quantity);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Item added to inventory successfully!");
            } else {
                System.out.println("Failed to add item to inventory.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeItem(int storeId, int productId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "DELETE FROM Inventory WHERE store_id = ? AND product_id = ?";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, storeId);
            preparedStatement.setInt(2, productId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Item removed from inventory successfully!");
            } else {
                System.out.println("Failed to remove item from inventory.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewInventory(int storeId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "SELECT * FROM Inventory WHERE store_id = ?";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, storeId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                System.out.println("Inventory for Store " + storeId + ":");

                while (resultSet.next()) {
                    int productId = resultSet.getInt("product_id");
                    int quantity = resultSet.getInt("quantity");

                    System.out.println("Product ID: " + productId + ", Quantity: " + quantity);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateInventoryItem(int storeId, int productId, int quantity) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "UPDATE Inventory SET quantity = ? WHERE store_id = ? AND product_id = ?";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, quantity);
            preparedStatement.setInt(2, storeId);
            preparedStatement.setInt(3, productId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Inventory item updated successfully!");
            } else {
                System.out.println("Failed to update inventory item.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewItem(int storeId, int productId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        String sql = "SELECT * FROM Inventory WHERE store_id = ? AND product_id = ?";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, storeId);
            preparedStatement.setInt(2, productId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int quantity = resultSet.getInt("quantity");
                    System.out.println("Product ID: " + productId + ", Quantity: " + quantity);
                } else {
                    System.out.println("Item not found in inventory.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

