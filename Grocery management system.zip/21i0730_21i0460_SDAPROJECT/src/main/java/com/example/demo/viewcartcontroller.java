package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class viewcartcontroller {
    @FXML
    private TextField Cartid;
    private int id;
    @FXML
    private Button Viewcart;
    public void Viewcart() throws IOException {
        id=Integer.parseInt(Cartid.getText());
        Customer obj= new Customer();
        obj.viewcart(id);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("menu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) Viewcart.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
