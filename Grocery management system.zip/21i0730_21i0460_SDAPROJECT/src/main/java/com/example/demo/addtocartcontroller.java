package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class addtocartcontroller {
    @FXML
    private TextField Cartid;
    private int id;
    @FXML
    private TextField productid;
    private int prod_id;
    @FXML
    private TextField Quantity;
    private int quantity;

    @FXML
    private Button addtocart;

    public void addtocart() throws IOException {
        id=Integer.parseInt(Cartid.getText());
        prod_id=Integer.parseInt(productid.getText());
        quantity=Integer.parseInt(Quantity.getText());
        Customer obj = new Customer();
        obj.addtocart(id,prod_id,quantity);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("menu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) addtocart.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
