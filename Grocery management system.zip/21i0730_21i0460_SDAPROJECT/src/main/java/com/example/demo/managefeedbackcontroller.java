package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class managefeedbackcontroller {
    @FXML
    private Button viewfeedback;
    @FXML
    private Button replyfeedback;
    public void viewfeedback() throws IOException {
        Manager obj=new Manager();
        obj.viewFeedback();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Managermenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) replyfeedback.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void replyfeedback() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("replyfeedback.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) replyfeedback.getScene().getWindow();
        stage.setScene(new Scene(root));
    }


}
