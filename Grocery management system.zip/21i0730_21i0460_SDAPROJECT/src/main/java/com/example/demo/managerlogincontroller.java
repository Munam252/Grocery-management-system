package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class managerlogincontroller {
    @FXML
    private TextField username;
    private String USername;

    @FXML
    private TextField Password;

    private String pass;

    @FXML
    private Button login;

    public void setLogin() throws IOException {
        USername = username.getText();
        pass= Password.getText();
        Manager obj =new Manager();
        boolean result = obj.login(USername,pass);

        if(result)
        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Managermenu.fxml"));
            Parent root = fxmlLoader.load();

            // Set up the stage
            Stage stage = (Stage) login.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        else {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("managerlogin.fxml"));
            Parent root = fxmlLoader.load();

            // Set up the stage
            Stage stage = (Stage) login.getScene().getWindow();
            stage.setScene(new Scene(root));
        }

    }
}
