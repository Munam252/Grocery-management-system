package com.example.demo;
import java.sql.*;
public class Store {
    private int storeId;
    private String storeName;
    private String storeLocation;
    private int managerId;
    Store()
    {}

    public void addStore(String storeName, String storeLocation, int managerId) {
        String JDBC_URL = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String DB_USER = "root";
        String DB_PASSWORD = "Alyan@072";
        String sql = "INSERT INTO Store (store_name, store_location, manager_id) VALUES (?, ?, ?)";

        try (
                Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
                PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)
        ) {
            preparedStatement.setString(1, storeName);
            preparedStatement.setString(2, storeLocation);
            preparedStatement.setInt(3, managerId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Store added successfully!");
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int generatedId = generatedKeys.getInt(1);
                    System.out.println("Generated Store ID: " + generatedId);
                }
            } else {
                System.out.println("Failed to add store.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeStore(int storeId, String storeLocation) {
        String JDBC_URL = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String DB_USER = "root";
        String DB_PASSWORD = "Alyan@072";
        String sql = "DELETE FROM Store WHERE store_id = ? AND store_location = ?";

        try (
                Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
                PreparedStatement preparedStatement = connection.prepareStatement(sql)
        ) {
            preparedStatement.setInt(1, storeId);
            preparedStatement.setString(2, storeLocation);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Store removed successfully!");
            } else {
                System.out.println("Failed to remove store. Check the store ID and location.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewAllStores() {
        String JDBC_URL = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String DB_USER = "root";
        String DB_PASSWORD = "Alyan@072";
        String sql = "SELECT * FROM Store";

        try (
                Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql)
        ) {
            while (resultSet.next()) {
                int storeId = resultSet.getInt("store_id");
                String storeName = resultSet.getString("store_name");
                String storeLocation = resultSet.getString("store_location");
                int managerId = resultSet.getInt("manager_id");

                System.out.println("Store ID: " + storeId);
                System.out.println("Store Name: " + storeName);
                System.out.println("Store Location: " + storeLocation);
                System.out.println("Manager ID: " + managerId);
                System.out.println("----------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addItemtoinventory(int storeId, int productId, int quantity)
    {
        Inventory obj=new Inventory();
        obj.addItem(storeId,productId,quantity);
    }
    public void removeItemfrominventory(int storeId, int productId){
        Inventory obj=new Inventory();
        obj.removeItem(storeId,productId);
    }
    public void viewInventory(int storeId){
        Inventory obj=new Inventory();
        obj.viewInventory(storeId);
    }
    public void updateInventoryItem(int storeId, int productId, int quantity) {
        Inventory obj=new Inventory();
        obj.updateInventoryItem(storeId,productId,quantity);
    }
    public void viewItemofInventory(int storeId, int productId) {
        Inventory obj=new Inventory();
        obj.viewItem(storeId,productId);
    }
}