package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class replyfeedbackcontroller {
    @FXML
    private TextField feedbackid;
    private int id;
    @FXML
    private TextField reply;
    private String msg;

    @FXML
    private Button submit;

    public void replyfeedback() throws IOException {
        id=Integer.parseInt(feedbackid.getText());
        msg=reply.getText();

        Manager obj = new Manager();
        obj.replyfeedback(id,msg);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Managermenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) submit.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
