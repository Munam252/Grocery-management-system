package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class viewinventorycon {
    @FXML
    private TextField storeid;
    private int id;

    @FXML
    private Button view;

    public void viewinventory() throws IOException {
        id=Integer.parseInt(storeid.getText());
        Manager obj=new Manager();
        obj.viewInventory(id);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Managermenu.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) view.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
