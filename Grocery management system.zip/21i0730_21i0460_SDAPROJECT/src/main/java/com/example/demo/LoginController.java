package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField username;
    private String USername;

    @FXML
    private TextField Password;

    private String pass;
    @FXML
    private Button loginButton;
    @FXML
    private Button Signup;

    public void setLoginButton() throws IOException {

        USername = username.getText();

        pass= Password.getText();

        Customer obj =new Customer();
        boolean result = obj.login(USername,pass);

        if (result) {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("menu.fxml"));
            Parent root = fxmlLoader.load();

            // Set up the stage
            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        else {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
            Parent root = fxmlLoader.load();

            // Set up the stage
            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }


    }

    public void signup() throws IOException
    {
        System.out.println("Sign up");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Signup.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) Signup.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
