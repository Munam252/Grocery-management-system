package com.example.demo;

public interface user {
    String getName();
    String getPassword();
    String getcnic();
    String getEmail();
    String getAddress();
}
