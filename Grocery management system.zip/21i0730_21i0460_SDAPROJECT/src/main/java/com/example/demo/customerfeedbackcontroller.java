package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class customerfeedbackcontroller {
    @FXML
    private Button viewfeedback;
    @FXML
    private Button providefeedback;

    public void viewfeedback() throws IOException {
        Customer obj=new Customer();
        obj.viewFeedback();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("menu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) providefeedback.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void providefeedback() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("provideFeedback.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) providefeedback.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
