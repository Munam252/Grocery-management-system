package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class newPagecontroller {
    @FXML
    private TextField storename;
    private String name;
    @FXML
    private TextField storeloc;
    private String loc;
    @FXML
    private TextField managerid;
    private int id;

    @FXML
    private Button addstr;

    public void storeaddition() throws IOException {
       name=storename.getText();
       loc=storeloc.getText();
       id=Integer.parseInt(managerid.getText());
       Admin obj=new Admin();
       obj.addstore(name,loc,id);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) addstr.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
