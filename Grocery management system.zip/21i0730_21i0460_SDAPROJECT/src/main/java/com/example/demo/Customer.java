package com.example.demo;

import java.sql.*;

public class Customer implements user {
    private String name;
    private String password;
    private String cnic;
    private String email;
    private String address;

    public boolean loginstatus;
    private Feedback feedbacks;

    public Customer()
    {
        loginstatus=false;
    }

    public Customer(String username, String email, String address, String cnic, String password) {
        this.name = username;
        this.password = password;
        this.cnic = cnic;
        this.email = email;
        this.address = address;
        this.feedbacks=null;
    }

    public void makepaymentbycard(String cardnumber,int bill,int customer_id)
    {
        Payment obj =new Payment();
        obj.payByCard(cardnumber,bill,customer_id);
    }
    public void makepaymentbycash(int amount,int bill,int customer_id)
    {
        Payment obj =new Payment();
        obj.payByCash(amount,bill,customer_id);
    }
    public void viewpayments(int customer_id)
    {
        Payment obj = new Payment();
        obj.viewPaymentsByCustomer(customer_id);
    }
    public void addtocart(int cartid,int productid,int quantity)
    {
        CartProduct obj =new CartProduct();
        obj.addToCart(cartid,productid,quantity);
    }
    public void rmvfromcart(int cartid,int productid)
    {
        CartProduct obj =new CartProduct();
        obj.removeFromCart(cartid,productid);
    }
    public void viewcart(int cartid)
    {
        CartProduct obj =new CartProduct();
        obj.viewCart(cartid);
    }
    public void Feedback(int id, String msg)
    {
        feedbacks=new Feedback();
        feedbacks.saveFeedback(id,msg);
    }

    public void viewFeedback()
    {
        feedbacks=new Feedback();
        feedbacks.displayAllFeedback();
    }

    public boolean login(String inputUsername, String inputPassword) {
        // JDBC URL, username, and password of MySQL server
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to check if the provided username and password exist
            String selectSql = "SELECT * FROM Customer WHERE name = ? AND password = ?";

            // Creating a PreparedStatement object to execute the SELECT query
            preparedStatement = connection.prepareStatement(selectSql);

            // Setting values for the parameters in the SELECT query
            preparedStatement.setString(1, inputUsername);
            preparedStatement.setString(2, inputPassword);

            // Executing the SELECT query and getting the result set
            resultSet = preparedStatement.executeQuery();

            // Checking if any matching records were found
            if (resultSet.next()) {

                System.out.println("Login successful! Login status updated.");
                return true;
            } else {
                System.out.println("Invalid username or password. Login failed.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (resultSet != null) {
                    ((ResultSet) resultSet).close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void logout(String inputUsername) {
        // JDBC URL, username, and password of MySQL server
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to update loginStatus to false for the provided username
            String updateSql = "UPDATE Customer SET loginstatus = false WHERE name = ?";

            // Creating a PreparedStatement object to execute the UPDATE query
            preparedStatement = connection.prepareStatement(updateSql);

            // Setting values for the parameters in the UPDATE query
            preparedStatement.setString(1, inputUsername);

            // Executing the UPDATE query
            int rowsAffected = preparedStatement.executeUpdate();

            // Checking the result
            if (rowsAffected > 0) {
                System.out.println("Logout successful! Login status updated.");
            } else {
                System.out.println("Logout failed. User not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void registration() {
        // JDBC URL, username, and password of MySQL server
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to insert customer information
            String sql = "INSERT INTO Customer (name, email, address, cnic, password) VALUES (?, ?, ?, ?, ?)";

            // Creating a PreparedStatement object to execute the query
            preparedStatement = connection.prepareStatement(sql);

            // Setting values for the parameters in the SQL query
            preparedStatement.setString(1, this.name);
            preparedStatement.setString(2, this.email);
            preparedStatement.setString(3, this.address);
            preparedStatement.setString(4, this.cnic);
            preparedStatement.setString(5, this.password);

            // Executing the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Checking the result
            if (rowsAffected > 0) {
                System.out.println("Registration successful!");
            } else {
                System.out.println("Registration failed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPassword() {
        return password;
    }
    @Override
    public String getcnic() {
        return cnic;
    }

    @Override
    public String getEmail() {
        return email;
    }
    @Override
    public String getAddress() {
        return address;
    }
}
