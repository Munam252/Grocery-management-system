package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Admin implements user {
    private String name;
    private String email;
    private String address;
    private String cnic;
    private String password;

    public Admin(String name, String email, String address, String cnic, String password) {
        this.name = name;
        this.email = email;
        this.address = address;
        this.cnic = cnic;
        this.password = password;
    }

    public Admin(){}

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getcnic() {
        return cnic;
    }
    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public boolean login(String Username,String pass) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to check if the provided username and password exist in the admin table
            String sql = "SELECT * FROM admin WHERE name = ? AND password = ?";

            // Creating a PreparedStatement object to execute the SELECT query
            preparedStatement = connection.prepareStatement(sql);

            // Setting values for the parameters in the SELECT query
            preparedStatement.setString(1, Username);
            preparedStatement.setString(2, pass);

            // Executing the SELECT query and getting the result set
            resultSet = preparedStatement.executeQuery();
            // Checking if any matching records were found
            if (resultSet.next()) {
                System.out.println("Login successful! Login status updated.");
                return true;
            } else {
                System.out.println("Invalid admin name or password. Login failed.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void registration(String NAME,String mail,String add,String CNIC,String pass,String Loc) {
        // JDBC URL, username, and password of MySQL server
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";

        // JDBC variables for opening, closing, and managing connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // SQL query to insert manager information
            String sql = "INSERT INTO Manager (name, email, address, cnic, password, store_location) VALUES (?, ?, ?, ?, ?, ?)";

            // Creating a PreparedStatement object to execute the query
            preparedStatement = connection.prepareStatement(sql);

            // Setting values for the parameters in the SQL query
            preparedStatement.setString(1, NAME);
            preparedStatement.setString(2, mail);
            preparedStatement.setString(3, add);
            preparedStatement.setString(4, CNIC);
            preparedStatement.setString(5, pass);
            preparedStatement.setString(6, Loc);

            // Executing the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Checking the result
            if (rowsAffected > 0) {
                System.out.println("Registration successful!");
            } else {
                System.out.println("Registration failed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing resources in the reverse order of their creation
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void addstore(String name, String loc, int id)
    {
        Store obj =new Store();
        obj.addStore(name,loc,id);
    }
    public void removestore(int id,String loc)
    {
        Store obj =new Store();
        obj.removeStore(id,loc);
    }
    public void viewstore()
    {
        Store obj =new Store();
        obj.viewAllStores();
    }
    public void addtoproductcatalog(int id,String category,String manufacturer)
    {
        ProductCatalog obj=new ProductCatalog();
        obj.addToProductCatalog(id,category,manufacturer);
    }
    public void rmvfromproductcatalog(int id,String category,String manufacturer)
    {
        ProductCatalog obj=new ProductCatalog();
        obj.removeFromProductCatalog(id,category,manufacturer);
    }
    public void viewproductcatalog()
    {
        ProductCatalog obj=new ProductCatalog();
        obj.viewProductCatalog();
    }

}
