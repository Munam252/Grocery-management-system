package com.example.demo;

import java.sql.*;

public class Payment {
    private int amount;
    private int totalBill;
    private int customerId;
    private String paymentMethod;

    public void payByCash(int amount, int totalBill, int customerId) {
        this.amount = amount;
        this.totalBill = totalBill;
        this.customerId = customerId;
        this.paymentMethod = "Cash";
        savePaymentData();
    }

    public void payByCard(String cardnumber, int totalBill, int customerId)
    {
        BankAccount obj = new BankAccount();
        boolean paymentResult = obj.makePayment(cardnumber,totalBill);
        if (paymentResult) {
            System.out.println("Payment Confirmed!");
            this.amount = totalBill;
            this.totalBill = totalBill;
            this.customerId = customerId;
            this.paymentMethod = "Card";
            savePaymentData();
        } else {
            System.out.println("Payment failed. Insufficient funds.");
        }
    }
    private void savePaymentData() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String sql = "INSERT INTO Payments (Amount, TotalBill, CustomerID, PaymentDate, PaymentMethod) VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, amount);
                preparedStatement.setInt(2, totalBill);
                preparedStatement.setInt(3, customerId);
                preparedStatement.setString(4, paymentMethod);
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Payment saved successfully!");
                } else {
                    System.out.println("Error: Payment not saved.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error: Payment not saved. Check database connection and input values.");
        }
    }
    public void viewAllPayments() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String sql = "SELECT * FROM Payments";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        int paymentId = resultSet.getInt("PaymentID");
                        int amount = resultSet.getInt("Amount");
                        int totalBill = resultSet.getInt("TotalBill");
                        int customerId = resultSet.getInt("CustomerID");
                        String paymentMethod = resultSet.getString("PaymentMethod");
                        String paymentDate = resultSet.getString("PaymentDate");

                        System.out.println("Payment ID: " + paymentId);
                        System.out.println("Amount: " + amount);
                        System.out.println("Total Bill: " + totalBill);
                        System.out.println("Customer ID: " + customerId);
                        System.out.println("Payment Method: " + paymentMethod);
                        System.out.println("Payment Date: " + paymentDate);
                        System.out.println("------------------------------");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error: Unable to retrieve payments. Check database connection.");
        }
    }
    public void viewPaymentsByCustomer(int customerId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/SDAPROJECT";
        String dbUser = "root";
        String dbPassword = "Alyan@072";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String sql = "SELECT * FROM Payments WHERE CustomerID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, customerId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        int paymentId = resultSet.getInt("PaymentID");
                        int amount = resultSet.getInt("Amount");
                        int totalBill = resultSet.getInt("TotalBill");
                        String paymentMethod = resultSet.getString("PaymentMethod");
                        String paymentDate = resultSet.getString("PaymentDate");

                        System.out.println("Payment ID: " + paymentId);
                        System.out.println("Amount: " + amount);
                        System.out.println("Total Bill: " + totalBill);
                        System.out.println("Customer ID: " + customerId);
                        System.out.println("Payment Method: " + paymentMethod);
                        System.out.println("Payment Date: " + paymentDate);
                        System.out.println("------------------------------");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error: Unable to retrieve payments. Check database connection.");
        }
    }
}


