package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class paymentcontroller {
    @FXML
    private Button viewPayments;
    @FXML
    private Button paymentbycash;
    @FXML
    private Button paymentbycard;
    public void viewPayments() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("viewPaymentsbyCustomer.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) viewPayments.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void paymentbycash() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("paymentbycash.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) paymentbycash.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void paymentbycard() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("paymentbycard.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) paymentbycard.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
