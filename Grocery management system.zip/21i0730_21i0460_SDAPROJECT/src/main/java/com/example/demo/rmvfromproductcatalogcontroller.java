package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class rmvfromproductcatalogcontroller {
    @FXML
    private TextField productid;
    private int id;
    @FXML
    private TextField category;
    private String cat;
    @FXML
    private TextField manufacturer;
    private String manu;

    @FXML
    private Button remove;

    public void rmvfromcatalog() throws IOException {
        id=Integer.parseInt(productid.getText());
        cat=category.getText();
        manu=manufacturer.getText();
        Admin obj =new Admin();
        obj.rmvfromproductcatalog(id,cat,manu);
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) remove.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}
