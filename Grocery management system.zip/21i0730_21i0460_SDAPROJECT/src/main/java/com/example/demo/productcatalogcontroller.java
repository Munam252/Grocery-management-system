package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class productcatalogcontroller {
    @FXML
    private Button add;
    @FXML
    private Button remove;
    @FXML
    private Button view;

    public void addtoproductcatalog() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("addtoproductcatalog.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) add.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void rmvfromproductcatalog() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("rmvfromproductcatalog.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = (Stage) remove.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    public void viewproductcatalog() throws IOException {
       Admin obj =new Admin();
       obj.viewproductcatalog();

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Adminmenu.fxml"));
        Parent root = fxmlLoader.load();

        // Set up the stage
        Stage stage = (Stage) view.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
